﻿# ARCHITECTURE.md — Dengue Guard

## System Overview

Dengue Guard is a **fully client-side, offline-capable** early-warning dashboard for dengue outbreak prediction at ward level across Bangladesh city corporations. All computation — feature engineering, gradient-boosting tree inference, and visualisation — runs in the user's browser. There is no server, no cloud API, and no database connection required after the initial page load.

---

## Data Flow Diagram

```
┌──────────────────────────────────────────────────────────────────┐
│                        OFFLINE BROWSER                           │
│                                                                  │
│  ┌─────────────┐    ┌──────────────────┐    ┌────────────────┐  │
│  │ dataset.js  │    │   engine.js       │    │    app.js      │  │
│  │ (CSV embed) │───▶│  parseCSV()       │───▶│  Dashboard UI  │  │
│  └─────────────┘    │  buildWards()     │    │  5 Tabs:       │  │
│                     │  originFeatures() │    │  • Risk board  │  │
│  ┌─────────────┐    │  withSeason()     │    │  • Ward dive   │  │
│  │  model.js   │    │  rawPredict()     │    │  • What-if     │  │
│  │ (GBT trees) │───▶│  forecast()       │───▶│  • Validation  │  │
│  └─────────────┘    │  contributions()  │    │  • How it works│  │
│                     │  applyScenario()  │    └────────────────┘  │
│  ┌─────────────┐    └──────────────────┘                         │
│  │ metrics.js  │───────────────────────────▶ Model Validation Tab│
│  │ (test stats)│                                                  │
│  └─────────────┘                                                  │
│                                                                  │
│  Optional: User uploads their own .csv → same pipeline          │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────── PYTHON TRAINING (offline, done once) ────┐
│                                                                  │
│  hackathon_dataset.csv (31,320 rows, 60 wards, 2016–2025)        │
│          │                                                       │
│          ▼                                                       │
│  Feature Engineering                                             │
│  • Rainfall lags 0–7 weeks + 2w/4w/8w sums                      │
│  • Temp & humidity at lag 0/2/4 weeks + 4-week mean             │
│  • Recent case trend (t0–t3, mean, slope)                        │
│  • Ward vulnerability (water-logging, sanitation, density)       │
│  • Target-week seasonality (sin/cos of day-of-year)              │
│          │                                                       │
│          ▼                                                       │
│  Chronological Train / Val / Test Split                          │
│  Train: 2016-01 → 2022-12   (feature learning + tree growth)    │
│  Val:   2023-01 → 2023-12   (early-stop, tier threshold calib.)  │
│  Test:  2024-01 → 2025-12   (single held-out score, never seen)  │
│          │                                                       │
│  3 Gradient Boosted Trees per horizon (+2w / +3w / +4w):        │
│  • Mean model  — Poisson log-link (scikit-learn HistGBR)        │
│  • Lo model    — 10th-percentile quantile regression             │
│  • Hi model    — 90th-percentile quantile regression             │
│          │                                                       │
│          ▼                                                       │
│  Serialise trees → model.js (JSON, evaluated in browser)        │
│  Serialise metrics → metrics.js (test MAE/RMSE/R²/confusion)    │
│  Serialise dataset → dataset.js (embedded CSV string)           │
└──────────────────────────────────────────────────────────────────┘
```

---

## Feature Engineering Pipeline

| Feature Group | Features | Lag / Window |
|---|---|---|
| **Rainfall lags** | `rain_lag0w` … `rain_lag7w` | 0–7 weeks before origin |
| **Rainfall sums** | `rain_sum_2w`, `rain_sum_4w`, `rain_sum_8w`, `rain_sum_wk4_7` | Rolling sums |
| **Temperature** | `temp_lag0w`, `temp_lag2w`, `temp_lag4w`, `temp_mean_4w` | Lag + 4-wk mean |
| **Humidity** | `hum_lag0w`, `hum_lag2w`, `hum_lag4w`, `hum_mean_4w` | Lag + 4-wk mean |
| **Case trend** | `cases_t0`–`cases_t3`, `cases_mean_4w`, `cases_trend` | Autoregressive |
| **Ward vulnerability** | `population_density_sqkm`, `water_logging_risk_index`, `sanitation_score`, `vulnerability_index` | Static ward attributes |
| **Seasonality** | `season_sin`, `season_cos` | sin/cos of target-week DoY |

All features are computed **strictly from data available before the origin date** — no future leakage.

---

## Chronological Validation Split

```
2016-01 ─────────────────────────── 2022-12 │ 2023 │ 2024-01 ──── 2025-12
         TRAIN (feature learning, GBT fit)   │  VAL  │   TEST (held-out, never seen)
                                             │       │
                                     Tier thresholds │ Final score reported
                                     calibrated here  in dashboard
```

**Why chronological (never shuffled)?**  
Dengue is a time-series problem. Random k-fold would leak future-week data into training, inflating metrics. Chronological splitting mimics real-world deployment: the model only ever sees past weeks when issuing a warning for a future week.

---

## Model Selection Rationale

| Factor | Choice | Reason |
|---|---|---|
| **Algorithm** | Histogram Gradient Boosted Trees (scikit-learn `HistGBR`) | Handles tabular data with rainfall lags well; no scaling needed; fast training |
| **Loss (mean)** | Poisson deviance | Weekly case counts are non-negative, over-dispersed counts — Poisson link matches the data generating process |
| **Loss (intervals)** | Pinball (quantile) at α=0.1 and α=0.9 | Gives calibrated 80% prediction bands; avoids parametric distribution assumptions |
| **Horizons** | +2w, +3w, +4w (direct, not recursive) | Direct multi-step avoids error compounding; each horizon is an independent model |
| **Risk tiers** | Calibrated on 2023 validation predictions | Thresholds (Low / Medium / High / Critical) are set so tier boundaries match the validation distribution, not arbitrary constants |

---

## Compute & API Cost Efficiency

- **Zero API calls at runtime** — all inference runs in pure JavaScript inside the browser using the pre-serialised tree JSON.
- **Zero LLM calls** — no GPT/Gemini/Claude involved in the prediction pipeline.
- **Zero server compute** — `server.js` is an optional static file server (Node `http` module, no framework); the app works by simply opening `index.html` directly.
- **Model size** — the 9 serialised tree models (3 horizons × 3 quantiles) are ~3 MB total, loaded once and cached by the browser.
- **Dataset size** — 31,320 rows embedded as a compressed CSV string in `dataset.js` (~2.5 MB gzipped).
- **Inference latency** — a full 60-ward forecast for one origin date completes in < 50 ms on a mid-range laptop CPU (measured in browser DevTools).
- **Caching** — Plotly chart `Plotly.react()` (not `newPlot`) diffs only changed traces, minimising DOM updates.

---

## File Structure

```
dengue-guard/
├── index.html          # Single-page app shell, tab structure
├── app.js              # Dashboard UI: KPIs, table, charts, what-if
├── engine.js           # Feature engineering + GBT inference in JS
├── style.css           # Dark-theme responsive layout
├── server.js           # Optional Node.js static server (zero deps)
├── package.json        # { "start": "node server.js" }
├── README.md           # Launch instructions + AI disclosure
├── ARCHITECTURE.md     # This file
└── data/
    ├── dataset.js      # Embedded CSV (31,320 rows, 60 wards, 2016–2025)
    ├── model.js        # Serialised GBT tree JSON (9 models)
    └── metrics.js      # Test-set metrics, confusion matrices, monthly actuals
└── lib/
    └── plotly.min.js   # Bundled Plotly.js (offline charts)
```

---

## Test-Set Performance Summary (held-out 2024–2025)

| Horizon | MAE | RMSE | R² | Tier Accuracy | 80% Coverage |
|---|---|---|---|---|---|
| +2 weeks | 1.007 | 2.023 | 0.725 | 87.4% | 94.2% |
| +3 weeks | 1.033 | 2.052 | 0.718 | 86.1% | 93.6% |
| +4 weeks | 1.218 | 2.418 | 0.608 | 83.9% | 92.9% |

All baselines (seasonal ward-month average, persistence) are substantially outperformed at every horizon.
