// "Stay in the Know" email sign-up (any form with class "subform").
// With the Node server (npm start) the address is POSTed to /api/subscribe and stored privately.
// Without a server (static hosting / file://) the form falls back to opening the visitor's email app, like the Contact page.
(function () {
  var forms = document.querySelectorAll("form.subform"); if (!forms.length) return;
  var RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  Array.prototype.forEach.call(forms, function (f) {
    var msg = f.querySelector(".submsg"), btn = f.querySelector("button[type=submit]"), label = btn.textContent;
    function say(t, ok) { msg.textContent = t; msg.className = "submsg " + (ok ? "ok" : "err"); msg.hidden = false; }
    f.addEventListener("submit", function (e) {
      e.preventDefault(); msg.hidden = true;
      var email = f.elements.email.value.trim();
      if (!RE.test(email)) { f.elements.email.focus(); return say("Please enter a valid email address.", false); }
      if (!f.elements.consent.checked) return say("Please tick the box to agree to receive emails.", false);
      var data = { email: email, consent: true, website: f.elements.website.value };
      btn.disabled = true; btn.textContent = "Subscribing…";
      var mailFallback = function () {
        location.href = "mailto:team@dengueguard.example?subject=" + encodeURIComponent("[Dengue Guard] Subscribe me to Stay in the Know") +
          "&body=" + encodeURIComponent("Please add this address to the Dengue Guard email updates list:\n" + email + "\n\nI agree to receive emails from Dengue Guard and can unsubscribe at any time.");
        say("Your email app should have opened with a sign-up message. Press Send there to subscribe.", true);
      };
      if (location.protocol === "file:") { btn.disabled = false; btn.textContent = label; return mailFallback(); }
      fetch("/api/subscribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) })
        .then(function (r) { return r.json().then(function (j) { return { j: j }; }); })
        .then(function (r) {
          if (r.j && r.j.ok) { f.reset(); say("Thank you! You are on the list for Dengue Guard updates. You can unsubscribe at any time.", true); }
          else say((r.j && r.j.error) || "Something went wrong. Please try again.", false);
        })
        .catch(function () { mailFallback(); })
        .then(function () { btn.disabled = false; btn.textContent = label; });
    });
  });
})();
