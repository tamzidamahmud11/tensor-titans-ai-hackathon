// "Submit your story" form + approved community stories (videos.html).
// With the Node server (npm start) the story is POSTed to /api/story and held for review.
// Without a server (static hosting / file://) the form falls back to opening the visitor's email app, like the Contact page.
(function () {
  var f = document.getElementById("storyform"); if (!f) return;
  var msg = document.getElementById("storymsg"), btn = f.querySelector("button[type=submit]"), cnt = document.getElementById("storycount");
  var story = f.elements.story, MIN = 40;
  var ROLE = { patient: "Had dengue", family: "Family member or friend", "health-worker": "Health worker", other: "Community member" };
  function say(t, ok) { msg.textContent = t; msg.className = "storymsg " + (ok ? "ok" : "err"); msg.hidden = false; }
  story.addEventListener("input", function () { cnt.textContent = story.value.length + " / 2000"; });

  f.addEventListener("submit", function (e) {
    e.preventDefault(); msg.hidden = true;
    if (story.value.trim().length < MIN) return say("Please write at least a few sentences (" + MIN + " characters).", false);
    if (!f.elements.consent.checked) return say("Please tick the box to confirm you agree to share your story.", false);
    var data = { name: f.elements.name.value, place: f.elements.place.value, role: f.elements.role.value, email: f.elements.email.value,
      story: story.value, consent: f.elements.consent.checked, website: f.elements.website.value };
    btn.disabled = true; btn.textContent = "Sending…";
    var mailFallback = function () {
      var body = "Name: " + data.name + "\nPlace: " + data.place + "\nI am: " + (ROLE[data.role] || "") + "\nEmail: " + data.email + "\n\nMy story:\n" + data.story +
        "\n\nI agree that Dengue Guard may publish my story after review.";
      location.href = "mailto:team@dengueguard.example?subject=" + encodeURIComponent("[Dengue Guard] My dengue story") + "&body=" + encodeURIComponent(body);
      say("Your email app should have opened with your story filled in. Press Send there to submit it.", true);
    };
    if (location.protocol === "file:") { btn.disabled = false; btn.textContent = "Submit my story"; return mailFallback(); }
    fetch("/api/story", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) })
      .then(function (r) { return r.json().then(function (j) { return { s: r.status, j: j }; }); })
      .then(function (r) {
        if (r.j && r.j.ok) { f.reset(); cnt.textContent = "0 / 2000"; f.hidden = true; say("Thank you for sharing your story. Our team reads every submission and will only publish it after review. Nothing appears on the site automatically.", true); }
        else say((r.j && r.j.error) || "Something went wrong. Please try again.", false);
      })
      .catch(function () { mailFallback(); })
      .then(function () { btn.disabled = false; btn.textContent = "Submit my story"; });
  });

  // Show stories the team has approved (server mode only). Built with textContent, so submitted text can never run as HTML.
  var box = document.getElementById("communitystories");
  if (box && location.protocol !== "file:") fetch("/api/stories").then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
    if (!j || !j.stories || !j.stories.length) return;
    var grid = box.querySelector(".vgrid");
    j.stories.forEach(function (s) {
      var a = document.createElement("article"); a.className = "card scard";
      var p = document.createElement("p"); p.className = "sbody"; p.textContent = s.story;
      var m = document.createElement("div"); m.className = "vmeta";
      var w = document.createElement("span"); w.textContent = (s.name || "Anonymous") + (s.place ? " · " + s.place : "") + " · " + ROLE[s.role];
      m.appendChild(w); a.appendChild(p); a.appendChild(m); grid.appendChild(a);
    });
    box.hidden = false;
  }).catch(function () {});
})();
