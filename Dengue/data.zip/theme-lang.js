// Dark/Light Theme and English/Bengali Language Controller for Dengue Guard
(function() {
  const THEME_KEY = "dg_theme";
  const LANG_KEY = "dg_lang";

  // Translations dictionary
  const I18N = {
    en: {
      nav_home: "Home",
      nav_why: "Why it matters",
      nav_features: "Features",
      nav_how: "How it works",
      nav_prevention: "Prevention",
      nav_validation: "Validation",
      nav_news: "News",
      nav_videos: "Videos",
      nav_blogs: "Blogs",
      nav_events: "Events",
      nav_webinars: "Webinars",
      nav_community: "Community",
      nav_multimedia: "Multimedia",
      nav_about: "About us",
      nav_faq: "FAQ",
      nav_contact: "Contact",
      nav_dashboard: "Open the dashboard",
      hero_tag: "Early warning for Bangladesh city corporations",
      hero_title: "See dengue outbreaks weeks before they peak.",
      hero_lead: "Dengue Guard forecasts risk for every ward 2–4 weeks ahead, using weather lags, ward vulnerability and gradient-boosted trees — so health teams can act while there is still time to clear breeding sites.",
      hero_cta: "Open the dashboard →",
      btn_subscribe: "Subscribe",
      stay_heading: "Stay in the Know",
      stay_desc: "Get dengue risk updates, upcoming community cleanups, and prevention tips from Dengue Guard by email. Occasional messages only, and you can unsubscribe at any time."
    },
    bn: {
      nav_home: "হোম",
      nav_why: "কেন এটি জরুরি",
      nav_features: "বৈশিষ্ট্যসমূহ",
      nav_how: "কীভাবে কাজ করে",
      nav_prevention: "প্রতিরোধ ব্যবস্থা",
      nav_validation: "যাচাইকরণ",
      nav_news: "সংবাদ",
      nav_videos: "ভিডিও",
      nav_blogs: "ব্লগ",
      nav_events: "ইভেন্টস",
      nav_webinars: "ওয়েবিনার",
      nav_community: "কমিউনিটি",
      nav_multimedia: "মাল্টিমিডিয়া",
      nav_about: "আমাদের সম্পর্কে",
      nav_faq: "প্রশ্নোত্তর",
      nav_contact: "যোগাযোগ",
      nav_dashboard: "ড্যাশবোর্ড খুলুন",
      hero_tag: "বাংলাদেশ সিটি কর্পোরেশনের জন্য আগাম সতর্কবার্তা",
      hero_title: "ডেঙ্গুর প্রাদুর্ভাব তীব্র হওয়ার আগেই পূর্বাভাস দেখুন।",
      hero_lead: "ডেঙ্গু গার্ড আবহাওয়ার বিলম্ব, ওয়ার্ডের ঝুঁকি এবং গ্র্যাডিয়েন্ট-বুস্টেড ট্রি মডেল ব্যবহার করে ২-৪ সপ্তাহ আগেই প্রতিটি ওয়ার্ডের ঝুঁকি পূর্বাভাস দেয় — যাতে হাসপাতাল ভর্তি বাড়ার আগেই লার্ভা নিধন শুরু করা যায়।",
      hero_cta: "ড্যাশবোর্ড খুলুন →",
      btn_subscribe: "সাবস্ক্রাইব করুন",
      stay_heading: "সর্বশেষ তথ্যের সাথে থাকুন",
      stay_desc: "ইমেইলে ডেঙ্গু সতর্কবার্তা, নতুন ফিচার এবং প্রতিরোধ নির্দেশিকা পান। যেকোনো সময় আনসাবস্ক্রাইব করতে পারবেন।"
    }
  };

  // Get current theme
  function getTheme() {
    return localStorage.getItem(THEME_KEY) || "light";
  }

  // Apply theme
  function setTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem(THEME_KEY, theme);
    updateThemeButtons(theme);
  }

  function updateThemeButtons(theme) {
    document.querySelectorAll(".theme-toggle-btn").forEach(btn => {
      if (theme === "dark") {
        btn.innerHTML = `<span aria-hidden="true">☀️</span> <span class="theme-text">Light</span>`;
        btn.setAttribute("aria-label", "Switch to light mode");
      } else {
        btn.innerHTML = `<span aria-hidden="true">🌙</span> <span class="theme-text">Dark</span>`;
        btn.setAttribute("aria-label", "Switch to dark mode");
      }
    });
  }

  // Language management
  function getLang() {
    return localStorage.getItem(LANG_KEY) || "en";
  }

  function setLang(lang) {
    document.documentElement.setAttribute("lang", lang);
    localStorage.setItem(LANG_KEY, lang);
    applyTranslations(lang);
    updateLangButtons(lang);
  }

  function updateLangButtons(lang) {
    document.querySelectorAll(".lang-toggle-btn").forEach(btn => {
      btn.innerHTML = lang === "bn" ? `🌐 English` : `🌐 বাংলা`;
      btn.setAttribute("aria-label", lang === "bn" ? "Switch to English" : "বাংলায় দেখুন");
    });
  }

  const origTextMap = new WeakMap();
  let origTitle = null;
  let domObserver = null;
  let isApplying = false;

  const SKIP_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "CODE", "PRE", "SVG"]);
  const TRANSLATABLE_ATTRS = ["placeholder", "title", "aria-label", "alt"];

  function normalizeText(str) {
    return str.replace(/\s+/g, " ").trim();
  }

  function shouldSkipNode(node) {
    let el = node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
    while (el) {
      if (SKIP_TAGS.has(el.tagName)) return true;
      if (el.classList && (el.classList.contains("lang-toggle-btn") || el.classList.contains("theme-toggle-btn"))) {
        return true;
      }
      el = el.parentElement;
    }
    return false;
  }

  function translateTextNode(node, lang, bnDict) {
    if (shouldSkipNode(node)) return;
    if (!origTextMap.has(node)) {
      origTextMap.set(node, node.nodeValue);
    }
    const orig = origTextMap.get(node);
    if (lang !== "bn") {
      if (node.nodeValue !== orig) node.nodeValue = orig;
      return;
    }
    const norm = normalizeText(orig);
    if (!norm) return;
    const translated = bnDict[norm];
    if (translated) {
      const lead = orig.match(/^\s*/)[0];
      const trail = orig.match(/\s*$/)[0];
      const nextVal = lead + translated + trail;
      if (node.nodeValue !== nextVal) node.nodeValue = nextVal;
    }
  }

  function translateElementAttrs(el, lang, bnDict) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE || shouldSkipNode(el)) return;
    TRANSLATABLE_ATTRS.forEach(attr => {
      if (!el.hasAttribute(attr)) return;
      const origAttr = "data-orig-" + attr;
      if (!el.hasAttribute(origAttr)) {
        el.setAttribute(origAttr, el.getAttribute(attr));
      }
      const orig = el.getAttribute(origAttr);
      if (lang !== "bn") {
        if (el.getAttribute(attr) !== orig) el.setAttribute(attr, orig);
        return;
      }
      const norm = normalizeText(orig);
      if (norm && bnDict[norm]) {
        el.setAttribute(attr, bnDict[norm]);
      }
    });
  }

  function walkAndTranslate(root, lang, bnDict) {
    if (!root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, null);
    let node = walker.currentNode;
    while (node) {
      if (node.nodeType === Node.TEXT_NODE) {
        translateTextNode(node, lang, bnDict);
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        translateElementAttrs(node, lang, bnDict);
      }
      node = walker.nextNode();
    }
  }

  function ensureObserver() {
    if (domObserver || !document.body) return;
    domObserver = new MutationObserver(mutations => {
      if (isApplying || getLang() !== "bn") return;
      const bnDict = window.DG_EN_TO_BN || {};
      isApplying = true;
      try {
        mutations.forEach(m => {
          m.addedNodes.forEach(n => walkAndTranslate(n, "bn", bnDict));
        });
      } finally {
        isApplying = false;
      }
    });
    domObserver.observe(document.body, { childList: true, subtree: true });
  }

  function applyTranslations(lang) {
    isApplying = true;
    try {
      const dict = I18N[lang] || I18N.en;
      document.querySelectorAll("[data-i18n]").forEach(el => {
        const key = el.getAttribute("data-i18n");
        if (dict[key]) {
          if (el.tagName === "INPUT" && el.hasAttribute("placeholder")) {
            el.placeholder = dict[key];
          } else {
            el.textContent = dict[key];
          }
        }
      });

      const bnDict = window.DG_EN_TO_BN || {};
      if (origTitle === null) origTitle = document.title;
      if (lang === "bn" && bnDict[normalizeText(origTitle)]) {
        document.title = bnDict[normalizeText(origTitle)];
      } else if (lang !== "bn" && origTitle !== null) {
        document.title = origTitle;
      }

      if (document.body) {
        walkAndTranslate(document.body, lang, bnDict);
        ensureObserver();
      }
    } finally {
      isApplying = false;
    }
  }

  // Setup header controls
  function initControls() {
    const nav = document.querySelector("header.nav nav");
    if (nav) {
      let controls = nav.querySelector(".nav-controls");
    if (!controls) {
      controls = document.createElement("div");
      controls.className = "nav-controls";

      // Theme toggle button
      const themeBtn = document.createElement("button");
      themeBtn.type = "button";
      themeBtn.className = "theme-toggle-btn";
      themeBtn.addEventListener("click", () => {
        const next = getTheme() === "dark" ? "light" : "dark";
        setTheme(next);
      });

      // Lang toggle button
      const langBtn = document.createElement("button");
      langBtn.type = "button";
      langBtn.className = "lang-toggle-btn";
      langBtn.addEventListener("click", () => {
        const next = getLang() === "bn" ? "en" : "bn";
        setLang(next);
      });

      controls.appendChild(themeBtn);
      controls.appendChild(langBtn);

      // Insert before the dashboard button
      const dashBtn = nav.querySelector("a.btn");
      if (dashBtn) {
        nav.insertBefore(controls, dashBtn);
      } else {
        nav.appendChild(controls);
      }
    }
    }

    setTheme(getTheme());
    setLang(getLang());
  }

  // Run on start
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initControls);
  } else {
    initControls();
  }

  // Immediate theme set to avoid flash
  const curTheme = localStorage.getItem(THEME_KEY) || "light";
  document.documentElement.setAttribute("data-theme", curTheme);
})();

;(function(){
  document.addEventListener('click', function(e){
    var btn = e.target.closest('.sidebar-toggle');
    if (!btn) return;
    var isMobile = window.innerWidth <= 960;
    if (isMobile) {
      var open = document.body.classList.toggle('sidebar-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    } else {
      var collapsed = document.body.classList.toggle('sidebar-collapsed');
      btn.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
    }
  });
})();
