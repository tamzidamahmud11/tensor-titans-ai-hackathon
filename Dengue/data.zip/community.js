// Community Forum and Peer Support for Dengue Guard
(function() {
  const DEFAULT_POSTS = [
    {
      id: "post-01",
      title: "How our apartment committee in Mirpur eliminated rooftop larvae in 48 hours",
      tag: "tip",
      tagName: "Field Guide",
      author: "Rafiqul Islam",
      area: "Mirpur Ward 11, Dhaka",
      date: "2026-11-23",
      content: "After seeing the dengue forecast for Ward 11 rise into Critical last week, our building committee inspected all 14 rooftop water storage overflow trays. 9 of them had active Aedes larvae! We treated them with temephos granules and added mesh strainers. Here is a simple checklist every building caretaker should run weekly.",
      upvotes: 42,
      replies: 8
    },
    {
      id: "post-02",
      title: "Warning signs: My daughter’s platelet dropped on Day 5 after fever broke",
      tag: "recovery",
      tagName: "Survivor Story",
      author: "Nasreen Sultana",
      area: "Shantinagar, Dhaka",
      date: "2026-11-20",
      content: "Many parents assume when the high fever drops, the danger has passed. For severe dengue, the 'critical phase' often begins right when the temperature normalizes. On Day 5 my daughter became lethargic and complained of severe stomach ache. We rushed to DMCH where her platelets had fallen to 38,000. Please monitor hematocrit and fluid intake constantly between Day 3 and 7!",
      upvotes: 89,
      replies: 15
    },
    {
      id: "post-03",
      title: "Clogged storm drain near Agrabad Commercial Area accumulating stagnant water",
      tag: "alert",
      tagName: "Hotspot Alert",
      author: "Imtiaz Mahmud",
      area: "Agrabad Ward 27, Chattogram",
      date: "2026-11-19",
      content: "Spotted significant standing water behind Agrabad Access Road culvert after unseasonal monsoon showers. We have reported this to CCC Conservancy Wing for the upcoming cleanup drive. Anyone nearby, please take precautions with window screens and mosquito coils during dusk hours.",
      upvotes: 27,
      replies: 4
    },
    {
      id: "post-04",
      title: "Does papaya leaf extract or dragon fruit juice actually raise platelet counts?",
      tag: "question",
      tagName: "Medical Q&A",
      author: "Tanvir Hasan",
      area: "Uttara, Dhaka",
      date: "2026-11-15",
      content: "My brother was diagnosed with dengue NS1 positive yesterday. Family members are advising pure papaya leaf juice. Does this interfere with medical treatment or have verified scientific efficacy? Our physician advised oral rehydration solution (ORS) and coconut water.",
      upvotes: 35,
      replies: 12
    }
  ];

  let posts = [];
  try {
    const saved = localStorage.getItem("dg_community_posts");
    posts = saved ? JSON.parse(saved) : DEFAULT_POSTS;
  } catch (e) {
    posts = DEFAULT_POSTS;
  }

  let userUpvotes = [];
  try {
    const uSaved = localStorage.getItem("dg_user_upvotes");
    userUpvotes = uSaved ? JSON.parse(uSaved) : [];
  } catch (e) {
    userUpvotes = [];
  }

  function savePosts() {
    try { localStorage.setItem("dg_community_posts", JSON.stringify(posts)); } catch (e) {}
  }
  function saveUpvotes() {
    try { localStorage.setItem("dg_user_upvotes", JSON.stringify(userUpvotes)); } catch (e) {}
  }

  function toast(msg) {
    const t = document.createElement("div");
    t.className = "toast";
    t.setAttribute("role", "status");
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2500);
  }

  function renderPosts(filter = "all") {
    const list = document.getElementById("discussionList");
    if (!list) return;

    const filtered = posts.filter(p => filter === "all" || p.tag === filter);

    list.innerHTML = filtered.map(p => {
      const hasUpvoted = userUpvotes.includes(p.id);
      return `
        <article class="discussion-card">
          <div class="discussion-header">
            <span class="discussion-tag tag-${p.tag}">${p.tagName}</span>
            <span style="font-size:0.8rem;color:var(--mu)">${p.date}</span>
          </div>
          <h3 class="discussion-title">${p.title}</h3>
          <p class="discussion-content">${p.content}</p>
          <div class="discussion-meta">
            <span>Posted by <b>${p.author}</b> (${p.area})</span>
            <span>💬 ${p.replies} responses</span>
            <button type="button" class="btn-upvote" data-id="${p.id}" ${hasUpvoted ? 'style="border-color:var(--ac);color:var(--ac)"' : ''}>
              ▲ Helpful (${p.upvotes})
            </button>
          </div>
        </article>
      `;
    }).join("");

    list.querySelectorAll(".btn-upvote").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.id;
        const post = posts.find(x => x.id === id);
        if (!post) return;

        if (userUpvotes.includes(id)) {
          post.upvotes = Math.max(0, post.upvotes - 1);
          userUpvotes = userUpvotes.filter(x => x !== id);
          toast("Upvote removed");
        } else {
          post.upvotes += 1;
          userUpvotes.push(id);
          toast("Marked as helpful!");
        }
        savePosts();
        saveUpvotes();
        renderPosts(filter);
      });
    });
  }

  function setupNewPostForm() {
    const form = document.getElementById("newPostForm");
    const msg = document.getElementById("newPostMsg");
    if (!form) return;

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const title = fd.get("title").trim();
      const tag = fd.get("tag");
      const author = fd.get("author").trim();
      const area = fd.get("area").trim();
      const content = fd.get("content").trim();

      if (!title || !content) return;

      const tagMap = {
        tip: "Field Guide",
        alert: "Hotspot Alert",
        recovery: "Survivor Story",
        question: "Medical Q&A"
      };

      const newPost = {
        id: "post-" + Date.now().toString(36),
        title,
        tag,
        tagName: tagMap[tag] || "Discussion",
        author: author || "Anonymous Neighbor",
        area: area || "Bangladesh",
        date: new Date().toISOString().split("T")[0],
        content,
        upvotes: 1,
        replies: 0
      };

      posts.unshift(newPost);
      savePosts();
      form.reset();

      if (msg) {
        msg.className = "event-feedback-msg success";
        msg.textContent = "Your story/discussion topic has been published to the community forum!";
        msg.hidden = false;
        setTimeout(() => { msg.hidden = true; }, 4000);
      }

      renderPosts();
      toast("Discussion published!");
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".community-filter-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".community-filter-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        renderPosts(btn.dataset.tag);
      });
    });

    setupNewPostForm();
    renderPosts();
  });
})();
