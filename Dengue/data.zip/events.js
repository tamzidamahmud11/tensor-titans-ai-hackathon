// Events management for Dengue Guard
// Community cleanups, awareness drives, fever camps, and prevention workshops across Bangladesh
(function() {
  const DEFAULT_EVENTS = [
    {
      id: "ev-01",
      title: "Ward 11 & Mirpur Community Source Reduction Drive",
      type: "cleanup",
      typeName: "Cleanup Drive",
      city: "DNCC",
      location: "Mirpur Section 10 Community Center & Ward 11 alleys, Dhaka",
      date: "2026-12-05",
      time: "08:30 AM – 12:30 PM BST",
      organizer: "DNCC Health Wing & Mirpur Resident Action Committee",
      spots: 50,
      registered: 34,
      desc: "Volunteer-led door-to-door inspection and standing water removal in rooftop flowerpots, construction materials, and clogged alley drains following the late November rain spell.",
      contact: "mirpur.clean@dengueguard.example",
      status: "upcoming"
    },
    {
      id: "ev-02",
      title: "Free Platelet & NS1 Antigen Screening Clinic",
      type: "clinic",
      typeName: "Health Screening",
      city: "DSCC",
      location: "Lalbagh Thana Health Complex, Old Dhaka",
      date: "2026-12-07",
      time: "09:00 AM – 04:00 PM BST",
      organizer: "Directorate General of Health Services (DGHS) & DSCC",
      spots: 150,
      registered: 112,
      desc: "Free on-the-spot CBC, platelet count checks, and NS1 antigen tests for residents showing fever symptoms in high-density wards of Old Dhaka. Medical officers on-site for immediate triage.",
      contact: "clinic.dscc@dengueguard.example",
      status: "upcoming"
    },
    {
      id: "ev-03",
      title: "School Dengue Awareness & 'Junior Inspectors' Training",
      type: "workshop",
      typeName: "Workshop",
      city: "DNCC",
      location: "Uttara Model School & College Auditorium, Sector 4, Dhaka",
      date: "2026-12-10",
      time: "10:30 AM – 01:00 PM BST",
      organizer: "Bangladesh Red Crescent Society & Dengue Guard Youth",
      spots: 80,
      registered: 65,
      desc: "Interactive educational workshop for students, parents, and teachers on identifying Aedes larvae (B-L-O-C-K method), safe repellent application, and organising student-led home checkups.",
      contact: "youth@dengueguard.example",
      status: "upcoming"
    },
    {
      id: "ev-04",
      title: "Chattogram Port & Agrabad Canal Drain Clearing Campaign",
      type: "cleanup",
      typeName: "Cleanup Drive",
      city: "CCC",
      location: "Agrabad Commercial Area & Ward 27, Chattogram",
      date: "2026-12-12",
      time: "08:00 AM – 01:00 PM BST",
      organizer: "Chattogram City Corporation (CCC) Conservancy Wing",
      spots: 60,
      registered: 42,
      desc: "Joint municipal worker and community cleanup targeting slow-draining culverts, discarded tires, and container accumulation in industrial and commercial corridors of Agrabad.",
      contact: "ccc.conservancy@dengueguard.example",
      status: "upcoming"
    },
    {
      id: "ev-05",
      title: "Khulna Division Dengue Surveillance & Clinical Triage Seminar",
      type: "workshop",
      typeName: "Medical Seminar",
      city: "KCC",
      location: "Khulna Medical College Conference Hall, Khulna",
      date: "2026-12-15",
      time: "02:30 PM – 05:30 PM BST",
      organizer: "Khulna Medical College Hospital & DGHS Surveillance Unit",
      spots: 100,
      registered: 88,
      desc: "Special clinical briefing for primary care physicians and clinic directors on managing secondary infections, Dengue Shock Syndrome fluid protocols, and utilizing early-warning data.",
      contact: "kmch.events@dengueguard.example",
      status: "upcoming"
    },
    {
      id: "ev-06",
      title: "Gazipur Industrial Zone Larvicide & Bio-Control Inspection",
      type: "inspection",
      typeName: "Larvae Inspection",
      city: "GCC",
      location: "Tongi Industrial Area & Ward 53, Gazipur",
      date: "2026-12-18",
      time: "09:00 AM – 02:00 PM BST",
      organizer: "Gazipur City Corporation Health Department & Local Garment Association",
      spots: 40,
      registered: 29,
      desc: "Biological larvicide application and factory water-storage auditing across major textile manufacturing clusters in Tongi to eliminate massive unmonitored roof reservoirs.",
      contact: "gazipur.health@dengueguard.example",
      status: "upcoming"
    },
    {
      id: "ev-07",
      title: "Rajshahi University Campus Green Zone Dengue Sweep",
      type: "cleanup",
      typeName: "Cleanup Drive",
      city: "RCC",
      location: "Rajshahi University Paris Road & Student Dormitories",
      date: "2026-12-20",
      time: "09:00 AM – 12:00 PM BST",
      organizer: "RU Volunteer Corps & Rajshahi City Corporation",
      spots: 75,
      registered: 58,
      desc: "Student-led campus sweep focusing on water accumulation in garden trays, canteen drainage sumps, and perimeter ditches around university residential halls.",
      contact: "ru.volunteers@dengueguard.example",
      status: "upcoming"
    },
    {
      id: "ev-08",
      title: "Rooftop Gardeners Mosquito Prevention Clinic & Seed Exchange",
      type: "campaign",
      typeName: "Community Campaign",
      city: "DNCC",
      location: "Dhanmondi Lake Amphitheater / Ravindra Sarobar, Dhaka",
      date: "2026-12-22",
      time: "03:00 PM – 06:00 PM BST",
      organizer: "Dhaka Urban Green Forum & Dengue Guard",
      spots: 120,
      registered: 94,
      desc: "Hands-on session for rooftop and balcony gardening enthusiasts on using sand and biological deterrents in planters, proper saucer drainage, and swapping insect-repellent herbs like Citronella and Basil.",
      contact: "greendhaka@dengueguard.example",
      status: "upcoming"
    }
  ];

  // Load from localStorage or defaults
  let events = [];
  try {
    const saved = localStorage.getItem("dg_events");
    events = saved ? JSON.parse(saved) : DEFAULT_EVENTS;
  } catch (e) {
    events = DEFAULT_EVENTS;
  }

  // Load user registrations
  let myRegistrations = [];
  try {
    const savedRegs = localStorage.getItem("dg_my_registrations");
    myRegistrations = savedRegs ? JSON.parse(savedRegs) : [];
  } catch (e) {
    myRegistrations = [];
  }

  let activeType = "all";
  let activeCity = "all";
  let searchQuery = "";

  function saveEvents() {
    try {
      localStorage.setItem("dg_events", JSON.stringify(events));
    } catch (e) {}
  }

  function saveRegistrations() {
    try {
      localStorage.setItem("dg_my_registrations", JSON.stringify(myRegistrations));
    } catch (e) {}
  }

  function toast(msg) {
    const t = document.createElement("div");
    t.className = "toast";
    t.setAttribute("role", "status");
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2500);
  }

  // Format date readable
  function formatDate(dStr) {
    const opts = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
    try {
      const d = new Date(dStr + "T00:00:00");
      return d.toLocaleDateString('en-US', opts);
    } catch (e) {
      return dStr;
    }
  }

  // Generate .ics calendar file for export
  function downloadCalendarFile(ev) {
    const dateFormatted = ev.date.replace(/-/g, "");
    const icsContent = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//Dengue Guard//Community Events//EN",
      "BEGIN:VEVENT",
      `UID:${ev.id}@dengueguard.org`,
      `DTSTAMP:${dateFormatted}T000000Z`,
      `DTSTART;VALUE=DATE:${dateFormatted}`,
      `SUMMARY:${ev.title}`,
      `DESCRIPTION:${ev.desc.replace(/\n/g, " ")} | Organized by: ${ev.organizer}`,
      `LOCATION:${ev.location}`,
      "STATUS:CONFIRMED",
      "END:VEVENT",
      "END:VCALENDAR"
    ].join("\r\n");

    const blob = new Blob([icsContent], { type: "text/calendar;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${ev.id}-dengueguard-event.ics`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    toast("Calendar event (.ics) downloaded!");
  }

  function renderEvents() {
    const grid = document.getElementById("eventsGrid");
    const countEl = document.getElementById("eventsCount");
    if (!grid) return;

    const filtered = events.filter(ev => {
      if (activeType !== "all" && ev.type !== activeType) return false;
      if (activeCity !== "all" && ev.city !== activeCity) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchTitle = ev.title.toLowerCase().includes(q);
        const matchLoc = ev.location.toLowerCase().includes(q);
        const matchDesc = ev.desc.toLowerCase().includes(q);
        const matchOrg = ev.organizer.toLowerCase().includes(q);
        if (!matchTitle && !matchLoc && !matchDesc && !matchOrg) return false;
      }
      return true;
    });

    if (countEl) {
      countEl.textContent = `Showing ${filtered.length} of ${events.length} dengue prevention events`;
    }

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div class="card" style="grid-column: 1/-1; text-align: center; padding: 48px 20px;">
          <h3 style="margin-bottom:8px">No matching events found</h3>
          <p style="color:var(--mu);margin-bottom:16px">Try adjusting your filters, searching for a different area or city corporation, or organize your own community event below!</p>
          <button class="btn" id="resetFiltersBtn" style="padding: 7px 18px; font-size: 0.9rem;">Reset all filters</button>
        </div>
      `;
      const resetBtn = document.getElementById("resetFiltersBtn");
      if (resetBtn) {
        resetBtn.addEventListener("click", () => {
          activeType = "all";
          activeCity = "all";
          searchQuery = "";
          const sInput = document.getElementById("eventSearchInput");
          if (sInput) sInput.value = "";
          const cSelect = document.getElementById("cityFilterSelect");
          if (cSelect) cSelect.value = "all";
          document.querySelectorAll(".events-filters .filter-btn").forEach(b => {
            b.classList.toggle("active", b.dataset.type === "all");
          });
          renderEvents();
        });
      }
      return;
    }

    grid.innerHTML = filtered.map(ev => {
      const isRegistered = myRegistrations.includes(ev.id);
      const remaining = Math.max(0, ev.spots - ev.registered);
      const isFull = remaining === 0;

      return `
        <article class="event-card" data-id="${ev.id}">
          <div class="event-header-banner type-${ev.type}">
            <span>${ev.typeName}</span>
            <span>${ev.city}</span>
          </div>
          <div class="event-body">
            <div class="event-date-row">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
              <span>${formatDate(ev.date)} · ${ev.time}</span>
            </div>
            <h3 class="event-title">${ev.title}</h3>
            <p class="event-desc">${ev.desc}</p>
            <div class="event-meta-list">
              <div class="event-meta-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                <span><b>Location:</b> ${ev.location}</span>
              </div>
              <div class="event-meta-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                <span><b>Organizer:</b> ${ev.organizer}</span>
              </div>
              <div class="event-meta-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                <span><b>Capacity:</b> ${ev.registered} registered (${remaining} spots open)</span>
              </div>
            </div>
            <div class="event-actions">
              ${isRegistered ? `
                <button type="button" class="btn-event btn-event-secondary btn-cancel-rsvp" data-id="${ev.id}">
                  ✓ You're Registered (Cancel)
                </button>
              ` : `
                <button type="button" class="btn-event btn-event-primary btn-rsvp" data-id="${ev.id}" ${isFull ? 'disabled' : ''}>
                  ${isFull ? 'Waitlist / Full' : 'Volunteer / Attend →'}
                </button>
              `}
              <button type="button" class="btn-event btn-event-secondary btn-cal" data-id="${ev.id}" title="Add to your calendar">
                📅 Add to Calendar
              </button>
              <button type="button" class="btn-event btn-event-secondary btn-share-event" data-id="${ev.id}" title="Share this event">
                🔗 Share
              </button>
            </div>
          </div>
        </article>
      `;
    }).join("");

    // Attach listeners
    grid.querySelectorAll(".btn-rsvp").forEach(btn => {
      btn.addEventListener("click", () => openRsvpModal(btn.dataset.id));
    });

    grid.querySelectorAll(".btn-cancel-rsvp").forEach(btn => {
      btn.addEventListener("click", () => cancelRsvp(btn.dataset.id));
    });

    grid.querySelectorAll(".btn-cal").forEach(btn => {
      btn.addEventListener("click", () => {
        const ev = events.find(x => x.id === btn.dataset.id);
        if (ev) downloadCalendarFile(ev);
      });
    });

    grid.querySelectorAll(".btn-share-event").forEach(btn => {
      btn.addEventListener("click", () => {
        const ev = events.find(x => x.id === btn.dataset.id);
        if (!ev) return;
        const text = `Join "${ev.title}" on ${ev.date} in ${ev.location} - via Dengue Guard Events`;
        if (navigator.share) {
          navigator.share({ title: ev.title, text, url: window.location.href }).catch(() => {});
        } else {
          navigator.clipboard.writeText(text + " " + window.location.href).then(() => {
            toast("Event details & link copied to clipboard!");
          }).catch(() => {
            prompt("Copy event link:", window.location.href);
          });
        }
      });
    });
  }

  // RSVP Modal
  function openRsvpModal(eventId) {
    const ev = events.find(x => x.id === eventId);
    if (!ev) return;

    let overlay = document.getElementById("rsvpModalOverlay");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "rsvpModalOverlay";
      overlay.className = "event-modal-overlay";
      document.body.appendChild(overlay);
    }

    overlay.innerHTML = `
      <div class="event-modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
        <button class="event-modal-close" aria-label="Close dialog">&times;</button>
        <span class="chip" style="margin-left:0;margin-bottom:8px">${ev.typeName} · ${ev.city}</span>
        <h3 id="modalTitle">${ev.title}</h3>
        <p><b>Date:</b> ${formatDate(ev.date)} (${ev.time})<br><b>Meeting Spot:</b> ${ev.location}</p>
        <form id="rsvpForm">
          <label>Full Name
            <input name="name" type="text" required placeholder="e.g. Tanvir Ahmed">
          </label>
          <label>Email Address
            <input name="email" type="email" required placeholder="name@example.com">
          </label>
          <label>Phone / WhatsApp Number
            <input name="phone" type="tel" required placeholder="e.g. 017xxxxxxxx">
          </label>
          <label>Your Role / Interest
            <select name="role">
              <option value="volunteer">Volunteer (Cleanup & Larvae Sweep)</option>
              <option value="resident">Resident Attendee</option>
              <option value="health-pro">Medical / Health Professional</option>
              <option value="student">Student / Youth Ambassador</option>
            </select>
          </label>
          <button type="submit" class="btn" style="margin-top:8px">Confirm Registration</button>
        </form>
        <div id="rsvpModalMsg" hidden></div>
      </div>
    `;

    overlay.style.display = "flex";

    const closeBtn = overlay.querySelector(".event-modal-close");
    closeBtn.addEventListener("click", () => {
      overlay.style.display = "none";
    });

    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) overlay.style.display = "none";
    });

    const form = overlay.querySelector("#rsvpForm");
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const name = fd.get("name");
      const email = fd.get("email");

      // Update event registered count
      ev.registered += 1;
      myRegistrations.push(ev.id);
      saveEvents();
      saveRegistrations();

      renderEvents();

      const msgBox = overlay.querySelector("#rsvpModalMsg");
      msgBox.className = "event-feedback-msg success";
      msgBox.textContent = `Thank you, ${name}! You are confirmed for this event. A confirmation reminder has been logged.`;
      msgBox.hidden = false;
      form.remove();

      setTimeout(() => {
        overlay.style.display = "none";
        toast("Registration confirmed!");
      }, 2000);
    });
  }

  function cancelRsvp(eventId) {
    const ev = events.find(x => x.id === eventId);
    if (ev) {
      ev.registered = Math.max(0, ev.registered - 1);
      myRegistrations = myRegistrations.filter(id => id !== eventId);
      saveEvents();
      saveRegistrations();
      renderEvents();
      toast("Your registration was cancelled.");
    }
  }

  // Setup Propose Event Form
  function setupProposeForm() {
    const form = document.getElementById("proposeEventForm");
    const msg = document.getElementById("proposeMsg");
    if (!form) return;

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const title = fd.get("title").trim();
      const type = fd.get("type");
      const city = fd.get("city");
      const date = fd.get("date");
      const time = fd.get("time").trim();
      const location = fd.get("location").trim();
      const organizer = fd.get("organizer").trim();
      const desc = fd.get("desc").trim();
      const contact = fd.get("contact").trim();

      if (!title || !date || !location || !desc) {
        if (msg) {
          msg.className = "event-feedback-msg";
          msg.style.background = "#fee2e2";
          msg.style.color = "#991b1b";
          msg.textContent = "Please fill in all required fields.";
          msg.hidden = false;
        }
        return;
      }

      const typeMap = {
        cleanup: "Cleanup Drive",
        clinic: "Health Screening",
        workshop: "Workshop",
        campaign: "Community Campaign",
        inspection: "Larvae Inspection"
      };

      const newEv = {
        id: "ev-user-" + Date.now().toString(36),
        title,
        type,
        typeName: typeMap[type] || "Community Event",
        city,
        location,
        date,
        time: time || "09:00 AM – 12:00 PM BST",
        organizer: organizer || "Local Ward Action Group",
        spots: 50,
        registered: 1,
        desc,
        contact: contact || "organizer@dengueguard.example",
        status: "upcoming"
      };

      events.unshift(newEv);
      saveEvents();
      form.reset();

      if (msg) {
        msg.className = "event-feedback-msg success";
        msg.textContent = "Your community event has been published to Dengue Guard and is now live for volunteers to join!";
        msg.hidden = false;
      }

      renderEvents();
      toast("Event created successfully!");

      const gridSection = document.getElementById("eventsSection");
      if (gridSection) {
        gridSection.scrollIntoView({ behavior: "smooth" });
      }
    });
  }

  // Init UI controls
  document.addEventListener("DOMContentLoaded", () => {
    // Type Filter Buttons
    document.querySelectorAll(".events-filters .filter-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".events-filters .filter-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        activeType = btn.dataset.type;
        renderEvents();
      });
    });

    // City Filter Select
    const citySelect = document.getElementById("cityFilterSelect");
    if (citySelect) {
      citySelect.addEventListener("change", (e) => {
        activeCity = e.target.value;
        renderEvents();
      });
    }

    // Search Input + Dropdown
    const sInput = document.getElementById("eventSearchInput");
    const sDropdown = document.getElementById("eventSearchDropdown");
    const updateSearchDropdown = (query) => {
      if (!sDropdown) return;
      const q = query.trim().toLowerCase();
      if (!q) {
        sDropdown.hidden = true;
        sDropdown.innerHTML = "";
        return;
      }
      const matches = events.filter(ev =>
        ev.title.toLowerCase().includes(q) ||
        ev.location.toLowerCase().includes(q) ||
        ev.city.toLowerCase().includes(q) ||
        ev.description.toLowerCase().includes(q) ||
        ev.organizer.toLowerCase().includes(q)
      ).slice(0, 8);

      if (matches.length === 0) {
        sDropdown.innerHTML = `<div class="events-search-empty">No matching events found</div>`;
      } else {
        sDropdown.innerHTML = matches.map(ev => `
          <button type="button" class="events-search-option" role="option" data-value="${escapeHtml(ev.title)}">
            <span class="events-search-option-title">${escapeHtml(ev.title)}</span>
            <span class="events-search-option-meta">${escapeHtml(ev.location)} · ${escapeHtml(ev.city)}</span>
          </button>
        `).join("");
      }
      sDropdown.hidden = false;
    };

    if (sInput) {
      sInput.addEventListener("input", (e) => {
        searchQuery = e.target.value.trim();
        updateSearchDropdown(e.target.value);
        renderEvents();
      });
      sInput.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && sDropdown) {
          sDropdown.hidden = true;
        }
      });
    }

    if (sDropdown) {
      sDropdown.addEventListener("click", (e) => {
        const opt = e.target.closest(".events-search-option");
        if (!opt || !sInput) return;
        const val = opt.dataset.value || "";
        sInput.value = val;
        searchQuery = val.trim();
        sDropdown.hidden = true;
        renderEvents();
      });
    }

    document.addEventListener("click", (e) => {
      if (sDropdown && !e.target.closest(".events-search-box")) {
        sDropdown.hidden = true;
      }
    });

    setupProposeForm();
    renderEvents();
  });
})();
