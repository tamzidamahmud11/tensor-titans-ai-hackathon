// Webinars management for Dengue Guard
(function() {
  const DEFAULT_WEBINARS = [
    {
      id: "web-01",
      title: "Anticipating Monsoon Peaks: Predictive Weather Lag Modeling for Public Health",
      status: "upcoming",
      date: "2026-12-08",
      time: "07:00 PM – 08:30 PM BST (Online Zoom)",
      speakers: "Dr. K. Rahman (Epidemiologist, IEDCR) & Dengue Guard Data Team",
      desc: "An in-depth technical walkthrough of how 2-8 week cumulative rainfall and humidity lags provide early indicators of Aedes mosquito population explosions across Bangladesh wards.",
      registeredCount: 240,
      zoomLink: "https://zoom.us/j/dengueguard-monsoon-forecast",
      recordingUrl: null
    },
    {
      id: "web-02",
      title: "Clinical Fluid Management & Dengue Shock Syndrome Prevention in Primary Clinics",
      status: "upcoming",
      date: "2026-12-14",
      time: "08:00 PM – 09:30 PM BST (Online)",
      speakers: "Prof. Dr. Farhana Begum (Internal Medicine, Dhaka Medical College Hospital)",
      desc: "Guidance for ward health center doctors and nurses on early detection of plasma leakage, timely IV saline administration, and monitoring platelet counts to avoid critical hospitalization delays.",
      registeredCount: 310,
      zoomLink: "https://zoom.us/j/dengueguard-clinical-triage",
      recordingUrl: null
    },
    {
      id: "web-03",
      title: "Community Larvae Control: Modern Wolbachia, Bio-Larvicides, and B-L-O-C-K Protocol",
      status: "recorded",
      date: "2026-11-18",
      time: "Recorded Session (1 hr 15 mins)",
      speakers: "Dr. S. Ahsan (Vector Control Specialist, WHO Collaborating Centre)",
      desc: "Comparative analysis of biological mosquito control interventions in Southeast Asia and practical steps for city corporations to deploy targeted larvicide before hospital admissions surge.",
      registeredCount: 520,
      zoomLink: null,
      recordingUrl: "https://www.youtube.com/watch?v=TbMCxl8YXTk"
    },
    {
      id: "web-04",
      title: "Citizen Science & Ward-Level Crowdsourcing for Urban Health Resiliency",
      status: "recorded",
      date: "2026-11-04",
      time: "Recorded Session (55 mins)",
      speakers: "Tariqul Islam (Urban Planner, BUET) & Local Ward Ambassadors",
      desc: "How neighborhood groups, schools, and volunteer inspectors can crowdsource standing-water reports and utilize predictive dashboards to guide municipal spraying teams.",
      registeredCount: 415,
      zoomLink: null,
      recordingUrl: "https://www.youtube.com/watch?v=Fixp7OAYFfA"
    }
  ];

  let webinars = [];
  try {
    const saved = localStorage.getItem("dg_webinars");
    webinars = saved ? JSON.parse(saved) : DEFAULT_WEBINARS;
  } catch (e) {
    webinars = DEFAULT_WEBINARS;
  }

  let userRegistrations = [];
  try {
    const regSaved = localStorage.getItem("dg_webinar_regs");
    userRegistrations = regSaved ? JSON.parse(regSaved) : [];
  } catch (e) {
    userRegistrations = [];
  }

  function saveWebinars() {
    try { localStorage.setItem("dg_webinars", JSON.stringify(webinars)); } catch (e) {}
  }
  function saveRegs() {
    try { localStorage.setItem("dg_webinar_regs", JSON.stringify(userRegistrations)); } catch (e) {}
  }

  function toast(msg) {
    const t = document.createElement("div");
    t.className = "toast";
    t.setAttribute("role", "status");
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2500);
  }

  function renderWebinars(filter = "all") {
    const grid = document.getElementById("webinarGrid");
    if (!grid) return;

    const filtered = webinars.filter(w => {
      if (filter === "all") return true;
      return w.status === filter;
    });

    grid.innerHTML = filtered.map(w => {
      const isReg = userRegistrations.includes(w.id);
      const isUpcoming = w.status === "upcoming";

      return `
        <article class="webinar-card">
          <div class="webinar-badge-bar ${isUpcoming ? 'badge-upcoming' : 'badge-recorded'}">
            <span>${isUpcoming ? '📅 Live Webinar' : '📼 Recorded Video'}</span>
            <span>${w.date}</span>
          </div>
          <div class="webinar-body">
            <h3 class="webinar-title">${w.title}</h3>
            <div class="webinar-speakers">
              <span><b>Presenter(s):</b> ${w.speakers}</span>
              <span><b>Time / Duration:</b> ${w.time}</span>
            </div>
            <p class="webinar-desc">${w.desc}</p>
            <div class="webinar-footer">
              <span style="font-size:0.85rem;color:var(--mu)">👥 ${w.registeredCount} participants</span>
              ${isUpcoming ? `
                ${isReg ? `
                  <button type="button" class="btn-event btn-event-secondary btn-unreg-web" data-id="${w.id}">
                    ✓ Registered (Join Link Saved)
                  </button>
                ` : `
                  <button type="button" class="btn-event btn-event-primary btn-reg-web" data-id="${w.id}">
                    Register Free →
                  </button>
                `}
              ` : `
                <a href="${w.recordingUrl}" target="_blank" rel="noopener noreferrer" class="btn-event btn-event-primary" style="text-decoration:none">
                  ▶ Watch Replay
                </a>
              `}
            </div>
          </div>
        </article>
      `;
    }).join("");

    grid.querySelectorAll(".btn-reg-web").forEach(btn => {
      btn.addEventListener("click", () => openWebinarModal(btn.dataset.id));
    });

    grid.querySelectorAll(".btn-unreg-web").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.id;
        userRegistrations = userRegistrations.filter(x => x !== id);
        const target = webinars.find(x => x.id === id);
        if (target) target.registeredCount = Math.max(0, target.registeredCount - 1);
        saveRegs();
        saveWebinars();
        renderWebinars(filter);
        toast("Webinar registration cancelled.");
      });
    });
  }

  function openWebinarModal(id) {
    const w = webinars.find(x => x.id === id);
    if (!w) return;

    let overlay = document.getElementById("webinarModalOverlay");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "webinarModalOverlay";
      overlay.className = "event-modal-overlay";
      document.body.appendChild(overlay);
    }

    overlay.innerHTML = `
      <div class="event-modal" role="dialog" aria-modal="true">
        <button class="event-modal-close" aria-label="Close dialog">&times;</button>
        <span class="chip" style="margin-left:0;margin-bottom:8px">Webinar Registration</span>
        <h3>${w.title}</h3>
        <p><b>Date & Time:</b> ${w.date} · ${w.time}<br><b>Platform:</b> Zoom Live / Google Meet</p>
        <form id="webinarRegForm">
          <label>Your Name
            <input name="name" type="text" required placeholder="e.g. Dr. Sabrina Akhter">
          </label>
          <label>Email Address (to receive webinar link)
            <input name="email" type="email" required placeholder="sabrina@example.com">
          </label>
          <label>Organization / Hospital / Affiliation
            <input name="org" type="text" placeholder="e.g. Dhaka Medical College / Resident">
          </label>
          <button type="submit" class="btn" style="margin-top:8px">Confirm Free Registration</button>
        </form>
        <div id="webModalMsg" hidden></div>
      </div>
    `;

    overlay.style.display = "flex";

    overlay.querySelector(".event-modal-close").addEventListener("click", () => {
      overlay.style.display = "none";
    });
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) overlay.style.display = "none";
    });

    const form = overlay.querySelector("#webinarRegForm");
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const name = fd.get("name");

      w.registeredCount += 1;
      userRegistrations.push(w.id);
      saveWebinars();
      saveRegs();

      renderWebinars();

      const msg = overlay.querySelector("#webModalMsg");
      msg.className = "event-feedback-msg success";
      msg.textContent = `Success, ${name}! Your seat is confirmed. The session access link has been reserved.`;
      msg.hidden = false;
      form.remove();

      setTimeout(() => {
        overlay.style.display = "none";
        toast("Webinar registration complete!");
      }, 2000);
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".webinar-filter-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".webinar-filter-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        renderWebinars(btn.dataset.filter);
      });
    });
    renderWebinars();
  });
})();
